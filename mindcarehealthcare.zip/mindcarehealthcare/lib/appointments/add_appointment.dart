import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:localstorage/localstorage.dart';
import 'package:mindcarehealthcare/main.dart';
import 'package:mindcarehealthcare/sqlite.dart';

class AddAppointmentPage extends StatefulWidget {
  const AddAppointmentPage({super.key, required this.refresh});

  final VoidCallback refresh;

  @override
  State<AddAppointmentPage> createState() => _AddAppointmentPageState();
}

class _AddAppointmentPageState extends State<AddAppointmentPage> {
  final _formKey = GlobalKey<FormState>();
  List<Map<String, dynamic>> doctors = [];
  String? selectedDoctor;
  int? selectedDoctorId;
  final TextEditingController dateController = TextEditingController();
  final TextEditingController timeController = TextEditingController();
  final TextEditingController reasonController = TextEditingController();
  bool isLoading = true;
  String? selectedAppointmentType;
  
  final List<String> appointmentTypes = [
    'Regular Checkup',
    'Consultation',
    'Follow-up',
    'Therapy Session',
    'Emergency'
  ];

  @override
  void initState() {
    super.initState();
    _fetchDoctors();
  }

  Future<void> _fetchDoctors() async {
    setState(() {
      isLoading = true;
    });
    
    final db = await Sqlite.db();
    final result = await db.query(
      'user',
      where: 'type = ?',
      whereArgs: ['Doctor'],
    );
    
    setState(() {
      doctors = result;
      isLoading = false;
    });
  }

  Future<void> _pickDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.blue,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        final formattedDate = DateFormat('yyyy-MM-dd').format(picked);
        dateController.text = formattedDate;
      });
    }
  }

  Future<void> _pickTime() async {
    TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.blue,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        final hour = picked.hour.toString().padLeft(2, '0');
        final minute = picked.minute.toString().padLeft(2, '0');
        timeController.text = '$hour:$minute';
      });
    }
  }

  Future<void> _saveAppointment() async {
    if (!_formKey.currentState!.validate() || selectedDoctorId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all required fields'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    try {
      setState(() {
        isLoading = true;
      });
      
      final db = await Sqlite.db();
      final i = await db.insert('appointments', {
        'date': dateController.text,
        'time': timeController.text,
        'userid': int.parse(getid()), 
        'username': localStorage.getItem("name")!.toString(),
        'doctorid': selectedDoctorId.toString(),
        'doctorname': selectedDoctor,
        'status': 'Scheduled',
        'reason': reasonController.text,
        'type': selectedAppointmentType,
      });

      print(i);
      
      setState(() {
        isLoading = false;
      });

      widget.refresh();
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Appointment scheduled successfully!'),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pop(context);
      
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
      
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text(
          "Schedule Appointment",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        elevation: 0,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSectionHeader('Select Doctor'),
                      const SizedBox(height: 16),
                      _buildDoctorSelection(),
                      const SizedBox(height: 24),
                      
                      _buildSectionHeader('Appointment Details'),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(child: _buildDateField()),
                          const SizedBox(width: 12),
                          Expanded(child: _buildTimeField()),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _buildAppointmentTypeDropdown(),
                      const SizedBox(height: 16),
                      _buildReasonField(),
                      const SizedBox(height: 32),
                      
                      _buildConfirmButton(),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.blue[800],
        ),
      ),
    );
  }

  Widget _buildDoctorSelection() {
    return doctors.isEmpty
        ? Center(
            child: Column(
              children: [
                Icon(Icons.person_off, size: 48, color: Colors.grey),
                SizedBox(height: 8),
                Text(
                  "No doctors available",
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),
          )
        : Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 1,
                  blurRadius: 3,
                  offset: Offset(0, 1),
                ),
              ],
            ),
            child: DropdownButtonFormField<String>(
              value: selectedDoctor,
              decoration: InputDecoration(
                labelText: "Select Doctor",
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.white,
                prefixIcon: Icon(Icons.person, color: Colors.blue),
              ),
              items: doctors.map((doctor) {
                return DropdownMenuItem<String>(
                  value: doctor['name'],
                  child: Text(doctor['name']),
                  onTap: () {
                    selectedDoctorId = doctor['id'];
                  },
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedDoctor = value;
                });
              },
              icon: Icon(Icons.arrow_drop_down_circle, color: Colors.blue),
              style: TextStyle(fontSize: 16, color: Colors.black87),
              validator: (value) => value == null ? "Please select a doctor" : null,
            ),
          );
  }

  Widget _buildDateField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: TextFormField(
        controller: dateController,
        readOnly: true,
        decoration: InputDecoration(
          labelText: "Date",
          hintText: "Select date",
          prefixIcon: Icon(Icons.calendar_today, color: Colors.blue),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        style: TextStyle(fontSize: 16),
        onTap: _pickDate,
        validator: (value) => value!.isEmpty ? "Required" : null,
      ),
    );
  }

  Widget _buildTimeField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: TextFormField(
        controller: timeController,
        readOnly: true,
        decoration: InputDecoration(
          labelText: "Time",
          hintText: "Select time",
          prefixIcon: Icon(Icons.access_time, color: Colors.blue),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        style: TextStyle(fontSize: 16),
        onTap: _pickTime,
        validator: (value) => value!.isEmpty ? "Required" : null,
      ),
    );
  }

  Widget _buildAppointmentTypeDropdown() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: DropdownButtonFormField<String>(
        value: selectedAppointmentType,
        decoration: InputDecoration(
          labelText: "Appointment Type",
          prefixIcon: Icon(Icons.medical_services, color: Colors.blue),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        ),
        items: appointmentTypes.map((type) {
          return DropdownMenuItem<String>(
            value: type,
            child: Text(type),
          );
        }).toList(),
        onChanged: (value) {
          setState(() {
            selectedAppointmentType = value;
          });
        },
        icon: Icon(Icons.arrow_drop_down_circle, color: Colors.blue),
        style: TextStyle(fontSize: 16, color: Colors.black87),
        validator: (value) => value == null ? "Please select appointment type" : null,
      ),
    );
  }

  Widget _buildReasonField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: TextFormField(
        controller: reasonController,
        decoration: InputDecoration(
          labelText: "Reason for Visit",
          hintText: "Describe your symptoms or reason",
          prefixIcon: Icon(Icons.description, color: Colors.blue),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        style: TextStyle(fontSize: 16),
        maxLines: 3,
        validator: (value) => value!.isEmpty ? "Please enter a reason" : null,
      ),
    );
  }

  Widget _buildConfirmButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue, Colors.blue.shade700],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.3),
            spreadRadius: 1,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: _saveAppointment,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, size: 24),
            SizedBox(width: 12),
            Text(
              "Confirm Appointment",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
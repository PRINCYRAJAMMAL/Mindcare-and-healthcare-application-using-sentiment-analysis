import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mindcarehealthcare/appointments/complete_appointment.dart';
import 'package:mindcarehealthcare/main.dart';
import 'package:mindcarehealthcare/sqlite.dart';

class DoctorAppointmentsPage extends StatefulWidget {
  const DoctorAppointmentsPage({super.key});
  @override
  State<DoctorAppointmentsPage> createState() => _DoctorAppointmentsPageState();
}

class _DoctorAppointmentsPageState extends State<DoctorAppointmentsPage> with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> appointments = [];
  bool isLoading = true;
  late TabController _tabController;
  final List<String> statusFilters = ['All', 'Pending', 'Completed'];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });
    fetchAppointments();
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> fetchAppointments() async {
    setState(() {
      isLoading = true;
    });
    
    final db = await Sqlite.db();
    final data = await db.query(
      'appointments',
      where: "doctorid = ?",
      whereArgs: [getid()]
    );
    
    setState(() {
      appointments = data;
      isLoading = false;
    });
  }

  List<Map<String, dynamic>> getFilteredAppointments() {
    if (_tabController.index == 0) {
      return appointments;
    } else if (_tabController.index == 1) {
      return appointments.where((appointment) => 
        appointment['status'] != 'Completed').toList();
    } else {
      return appointments.where((appointment) => 
        appointment['status'] == 'Completed').toList();
    }
  }

  void showAppointmentDetails(Map<String, dynamic> appointment) {
    if (appointment['status'] == 'Completed') {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green),
                SizedBox(width: 8),
                Text('Appointment Details', 
                  style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            content: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _detailItem(Icons.person, 'Patient', appointment['username']),
                  _detailItem(Icons.description, 'Summary', appointment['summary'] ?? 'No summary provided'),
                  _detailItem(Icons.medication, 'Prescription', appointment['prescriptions'] ?? 'No prescriptions'),
                  _detailItem(Icons.stars, 'Ratings', '${appointment['rating'] ?? 0}'),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text('Close'),
              ),
            ],
          );
        },
      );
    }
  }

  Widget _detailItem(IconData icon, String title, String content) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: Colors.blue),
          SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey[700])),
                SizedBox(height: 4),
                Text(content, style: TextStyle(fontSize: 16)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredAppointments = getFilteredAppointments();
    
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Theme.of(context).primaryColor,
        title: Text(
          'My Appointments',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: [
            Tab(text: 'All'),
            Tab(text: 'Pending'),
            Tab(text: 'Completed'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: fetchAppointments,
          ),
        ],
      ),
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : RefreshIndicator(
              onRefresh: fetchAppointments,
              child: filteredAppointments.isEmpty
                  ? _buildEmptyState()
                  : Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: ListView.builder(
                        itemCount: filteredAppointments.length,
                        itemBuilder: (context, index) {
                          final appointment = filteredAppointments[index];
                          return _buildAppointmentCard(appointment);
                        },
                      ),
                    ),
            ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.calendar_today,
            size: 80,
            color: Colors.grey[400],
          ),
          SizedBox(height: 16),
          Text(
            "No Appointments Found",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 8),
          Text(
            _tabController.index == 0
                ? "You don't have any appointments yet"
                : _tabController.index == 1
                    ? "No pending appointments"
                    : "No completed appointments",
            style: TextStyle(
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppointmentCard(Map<String, dynamic> appointment) {
    final bool isCompleted = appointment['status'] == 'Completed';
    
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => isCompleted
            ? showAppointmentDetails(appointment)
            : Get.to(() => CompleteAppointment(appointmentId: appointment["id"])),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: isCompleted ? Colors.green[100] : Colors.orange[100],
                    child: Icon(
                      isCompleted ? Icons.check_circle : Icons.pending_actions,
                      color: isCompleted ? Colors.green : Colors.orange,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          appointment['username'] ?? 'Unknown Patient',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          appointment['doctorname'] ?? 'Unknown Doctor',
                          style: TextStyle(
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  _buildStatusChip(appointment['status']),
                ],
              ),
              Divider(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildInfoItem(Icons.date_range, 'Date', 
                    _formatDate(appointment['date'] ?? 'Unknown')),

                  _buildInfoItem(Icons.medical_services, 'Type', 
                    appointment['type'] ?? 'Consultation'),
                ],
              ),
              SizedBox(height: 16),
              if (!isCompleted)
                ElevatedButton(
                  onPressed: () => Get.to(() => CompleteAppointment(appointmentId: appointment["id"])),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    minimumSize: Size(double.infinity, 40),
                  ),
                  child: Text('Complete Appointment'),
                )
              else
                OutlinedButton(
                  onPressed: () => showAppointmentDetails(appointment),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.blue),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    minimumSize: Size(double.infinity, 40),
                  ),
                  child: Text('View Details'),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusChip(String? status) {
    Color chipColor;
    Color textColor;
    
    switch (status) {
      case 'Completed':
        chipColor = Colors.green[100]!;
        textColor = Colors.green[800]!;
        break;
      case 'Pending':
        chipColor = Colors.orange[100]!;
        textColor = Colors.orange[800]!;
        break;
      default:
        chipColor = Colors.blue[100]!;
        textColor = Colors.blue[800]!;
    }
    
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: chipColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        status ?? 'Unknown',
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String title, String value) {
    return Column(
      children: [
        Icon(icon, color: Colors.blue, size: 20),
        SizedBox(height: 4),
        Text(
          title,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 12,
          ),
        ),
        SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  String _formatDate(String dateStr) {
    try {
      final parts = dateStr.split('-');
      if (parts.length >= 3) {
        return "${parts[2]}-${parts[1]}-${parts[0]}";
      }
      return dateStr;
    } catch (e) {
      return dateStr;
    }
  }
}
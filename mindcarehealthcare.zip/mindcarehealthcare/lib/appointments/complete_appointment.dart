import 'package:flutter/material.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'package:intl/intl.dart';

class CompleteAppointment extends StatefulWidget {
  final int appointmentId;
  
  const CompleteAppointment({super.key, required this.appointmentId});
  
  @override
  State<CompleteAppointment> createState() => _CompleteAppointmentState();
}

class _CompleteAppointmentState extends State<CompleteAppointment> {
  final TextEditingController summaryController = TextEditingController();
  final TextEditingController prescriptionController = TextEditingController();
  final TextEditingController prescriptionTimingController = TextEditingController();
  final TextEditingController rewardController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  Map<String, dynamic>? appointmentData;
  
  @override
  void initState() {
    super.initState();
    _loadAppointmentDetails();
  }
  
  Future<void> _loadAppointmentDetails() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final db = await Sqlite.db();
      final List<Map<String, dynamic>> results = await db.query(
        'appointments',
        where: 'id = ?',
        whereArgs: [widget.appointmentId],
      );
      
      if (results.isNotEmpty) {
        setState(() {
          appointmentData = results.first;
          
          // Pre-fill controllers with existing data if available
          if (appointmentData?['summary'] != null) {
            summaryController.text = appointmentData!['summary'];
          }
          if (appointmentData?['prescriptions'] != null) {
            prescriptionController.text = appointmentData!['prescriptions'];
          }
          if (appointmentData?['prescriptiontimings'] != null) {
            prescriptionTimingController.text = appointmentData!['prescriptiontimings'];
          }
          if (appointmentData?['reward'] != null) {
            rewardController.text = appointmentData!['reward'].toString();
          }
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading appointment: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> completeAppointment() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      String summary = summaryController.text;
      String prescription = prescriptionController.text;
      String prescriptionTiming = prescriptionTimingController.text;
      int reward = int.tryParse(rewardController.text) ?? 0;
      String completedDate = DateTime.now().toIso8601String();
      
      final db = await Sqlite.db();
      await db.update(
        'appointments',
        {
          'summary': summary,
          'prescriptions': prescription,
          'prescriptiontimings': prescriptionTiming,
          'reward': reward,
          'status': 'Completed',
          'completeddate': completedDate,
        }, 
        where: 'id = ?', 
        whereArgs: [widget.appointmentId],
      );

      Sqlite.incrementUserPoints(appointmentData!["userid"], reward);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Appointment completed successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context, true); // Return true to indicate successful completion
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error completing appointment: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Complete Appointment",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        elevation: 0,
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : appointmentData == null
          ? const Center(child: Text('Appointment not found'))
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildAppointmentInfoCard(),
                      const SizedBox(height: 24),
                      
                      Text(
                        'Appointment Summary',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      // Summary field
                      _buildTextField(
                        controller: summaryController,
                        label: "Summary",
                        hint: "Enter appointment summary",
                        icon: Icons.summarize,
                        maxLines: 4,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter a summary';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      
                      Text(
                        'Prescription Details',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      // Prescription field
                      _buildTextField(
                        controller: prescriptionController,
                        label: "Prescription",
                        hint: "Enter medications",
                        icon: Icons.medication_outlined,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter prescription details';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      
                      // Prescription timing field
                      _buildTextField(
                        controller: prescriptionTimingController,
                        label: "Medication Schedule",
                        hint: "E.g., 1-0-1 after meals",
                        icon: Icons.schedule,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter prescription timing';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      
                      Text(
                        'Patient Reward',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      // Reward field
                      _buildTextField(
                        controller: rewardController,
                        label: "Reward Points",
                        hint: "Enter reward points",
                        icon: Icons.stars,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter reward points';
                          }
                          if (int.tryParse(value) == null) {
                            return 'Please enter a valid number';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 32),
                      
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : completeAppointment,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).primaryColor,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 3,
                          ),
                          child: _isLoading
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.check_circle),
                                  SizedBox(width: 8),
                                  Text(
                                    "Complete Appointment",
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
  
  Widget _buildAppointmentInfoCard() {
    String appointmentDate = "N/A";
    if (appointmentData?['date'] != null) {
      try {
        final DateTime parsedDate = DateTime.parse(appointmentData!['date']);
        appointmentDate = DateFormat('EEEE, MMM d, yyyy').format(parsedDate);
      } catch (e) {
        appointmentDate = appointmentData!['date'];
      }
    }
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2),
                  radius: 24,
                  child: Icon(
                    Icons.calendar_today,
                    color: Theme.of(context).primaryColor,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        appointmentDate,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Text(
                        "Appointment #${widget.appointmentId}",
                        style: TextStyle(
                          color: Colors.grey[700],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            _buildInfoRow(
              Icons.person, 
              "Patient", 
              appointmentData?['username'] ?? "N/A"
            ),
            const SizedBox(height: 8),
            _buildInfoRow(
              Icons.medical_services, 
              "Doctor", 
              appointmentData?['doctorname'] ?? "N/A"
            ),
            if (appointmentData?['reason'] != null && appointmentData!['reason'].isNotEmpty) ...[
              const SizedBox(height: 8),
              _buildInfoRow(
                Icons.info_outline, 
                "Reason", 
                appointmentData!['reason']
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 16,
          color: Colors.grey[600],
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Theme.of(context).primaryColor, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red, width: 2),
        ),
        filled: true,
        fillColor: Colors.grey[100],
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      ),
    );
  }
  
  @override
  void dispose() {
    summaryController.dispose();
    prescriptionController.dispose();
    prescriptionTimingController.dispose();
    rewardController.dispose();
    super.dispose();
  }
}
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';
import 'package:localstorage/localstorage.dart';
import 'package:mindcarehealthcare/activity/activity_answers.dart';
import 'package:mindcarehealthcare/activity/do_activity.dart';
import 'package:mindcarehealthcare/activity/show_all_activities.dart';
import 'package:mindcarehealthcare/login/login_page.dart';
import 'package:mindcarehealthcare/patient/appointment/patient_appointment_list.dart';
import 'package:mindcarehealthcare/patient/feedback/feedback.dart';
import 'package:mindcarehealthcare/patient/profile.dart';
import 'package:mindcarehealthcare/prescription/prescription_list.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:convert';

class PatientHome extends StatefulWidget {
  const PatientHome({Key? key}) : super(key: key);

  @override
  State<PatientHome> createState() => _PatientHomeState();
}

class _PatientHomeState extends State<PatientHome> {
  int points = 0;
  List<Map<String, dynamic>> pendingAppointments = [];
  List<Map<String, dynamic>> incompleteActivities = [];

  dynamic userData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeData();

    Timer.periodic(Duration(seconds: 2), (t){
      _initializeData();
    });
  }
Future<void> _initializeData() async {
  try {
    final id = localStorage.getItem("id");
    final _db = await Sqlite.db();

    // Fetch pending appointments
    final appointments = await _db.query(
      'appointments',
      where: 'userid = ? AND status = ?',
      whereArgs: [id, 'Scheduled'],
      orderBy: 'date ASC',
    );

    // Fetch incomplete activities (activities that are NOT in questionanswers as completed)
    final activities = await _db.rawQuery('''
      SELECT * FROM activity 
      WHERE id NOT IN (
        SELECT activityid FROM questionanswers 
        WHERE userid = ? AND completed = 1
      )
      ORDER BY date ASC
    ''', [id]);

    userData = await _db.query(
      "user",
      where: 'id = ?',
      whereArgs: [id],
    );

    print(userData);

    setState(() {
      pendingAppointments = appointments;
      incompleteActivities = activities;
      isLoading = false;
      points = userData[0]["points"];
    });
  } catch (e) {
    print('Error initializing data: $e');
    setState(() {
      isLoading = false;
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Patient Dashboard",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle, size: 30),
            onPressed: () {
              Get.to(()=> Profile());
            },
          ),

                    IconButton(
            icon: const Icon(Icons.logout, size: 30),
            onPressed: () {

              Get.offAll(()=> LoginPage());
            },
          ),
        ],
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Points Card with Gradient
                    Container(
                      width: double.infinity,
                      height: 100,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF1E88E5), Color(0xFF64B5F6)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Your Health Points",
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                Text(
                                  "Keep it up!",
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.white70,
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Text(
                                  "${points}",
                                  style: const TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  size: 28,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Section title
                    const Text(
                      "Quick Actions",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Horizontal scrollable dashboard items
                    SizedBox(
                      height: 140,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          _buildDashboardItem("Appointments", Icons.calendar_today, Colors.blue, () {
                            Get.to(()=> PatientAppointmentList());
                          }),
                          _buildDashboardItem("Prescriptions", Icons.receipt, Colors.green, () {
                            Get.to(()=>PrescriptionList());
                          }),
                          _buildDashboardItem("Feedback", Icons.feedback, Colors.orange, () {
                            Get.to(()=> FeedbackPage());
                          }),

                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Pending Appointments Section
                    _buildSectionHeader(
                      "Upcoming Appointments",
                      Icons.calendar_today,
                      Colors.blue,
                      () {
                        Get.to(()=> PatientAppointmentList());
                      },
                    ),
                    
                    const SizedBox(height: 12),
                    
                    pendingAppointments.isEmpty
                        ? _buildEmptyState("No upcoming appointments", Icons.event_available)
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: pendingAppointments.length > 3 ? 3 : pendingAppointments.length,
                            itemBuilder: (context, index) {
                              final appointment = pendingAppointments[index];
                              return _buildAppointmentCard(appointment);
                            },
                          ),
                    
                    const SizedBox(height: 24),
                    
                    // Incomplete Activities Section
                    _buildSectionHeader(
                      "Activities To Complete",
                      Icons.directions_run,
                      Colors.orange,
                      () {
                        Get.to(()=>ShowAllActivities());
                      },
                    ),
                    
                    const SizedBox(height: 12),
                    
                    incompleteActivities.isEmpty
                        ? _buildEmptyState("No pending activities", Icons.task_alt)
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: incompleteActivities.length > 3 ? 3 : incompleteActivities.length,
                            itemBuilder: (context, index) {
                              final activity = incompleteActivities[index];
                              return _buildActivityCard(activity);
                            },
                          ),
                          
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildDashboardItem(String title, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 120,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 32, color: color),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, Color color, VoidCallback onTap) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(icon, size: 22, color: color),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        TextButton(
          onPressed: onTap,
          child: const Text("See All"),
        ),
      ],
    );
  }

  Widget _buildAppointmentCard(Map<String, dynamic> appointment) {
    // Parse date
    DateTime appointmentDate = DateTime.parse(appointment['date']);
    String formattedDate = "${appointmentDate.day}/${appointmentDate.month}/${appointmentDate.year}";
    String formattedTime = "${appointmentDate.hour}:${appointmentDate.minute.toString().padLeft(2, '0')}";

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Icon(
                  Icons.medical_services,
                  color: Colors.blue,
                  size: 24,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Dr. ${appointment['doctorname']}",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    formattedDate,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // Container(
                //   padding: const EdgeInsets.symmetric(
                //     horizontal: 10,
                //     vertical: 4,
                //   ),
                //   decoration: BoxDecoration(
                //     color: Colors.blue.withOpacity(0.1),
                //     borderRadius: BorderRadius.circular(12),
                //   ),
                //   child: Text(
                //     formattedTime,
                //     style: const TextStyle(
                //       color: Colors.blue,
                //       fontWeight: FontWeight.bold,
                //     ),
                //   ),
                // ),
                // const SizedBox(height: 4),
                Text(
                  appointment['status'].toUpperCase(),
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.orange,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityCard(Map<String, dynamic> activity) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Icon(
                  Icons.fitness_center,
                  color: Colors.orange,
                  size: 24,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    activity['name'],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    activity['description'],
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Get.to(()=>
                DoActivity(activity:  activity)
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              child: const Text(
                "Start",
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(String message, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 24),
      alignment: Alignment.center,
      child: Column(
        children: [
          Icon(
            icon,
            size: 48,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            message,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }
}
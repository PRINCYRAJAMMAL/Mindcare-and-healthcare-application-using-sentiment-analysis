import 'package:flutter/material.dart';

class PatientPrescriptionList extends StatelessWidget {
  const PatientPrescriptionList({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
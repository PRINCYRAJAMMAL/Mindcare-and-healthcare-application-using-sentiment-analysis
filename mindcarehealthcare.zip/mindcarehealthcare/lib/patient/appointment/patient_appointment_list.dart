import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';
import 'package:mindcarehealthcare/appointments/add_appointment.dart';
import 'package:mindcarehealthcare/main.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'package:intl/intl.dart';

class PatientAppointmentList extends StatefulWidget {
  const PatientAppointmentList({super.key});
  @override
  State<PatientAppointmentList> createState() => _PatientAppointmentListState();
}

class _PatientAppointmentListState extends State<PatientAppointmentList> with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> appointments = [];
  List<Map<String, dynamic>> filteredAppointments = [];
  String id = "";
  bool isLoading = true;
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    id = getid();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      _filterAppointments(_tabController.index);
    });
    _fetchAppointments();
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _fetchAppointments() async {
    setState(() {
      isLoading = true;
    });
    
    final db = await Sqlite.db();
    final result = await db.query('appointments', where: 'userid = ?', whereArgs: [getid()]);
    
    setState(() {
      appointments = result;
      _filterAppointments(_tabController.index);
      isLoading = false;
    });
  }
  
  void _filterAppointments(int tabIndex) {
    setState(() {
      if (tabIndex == 0) {
        filteredAppointments = List.from(appointments);
      } else if (tabIndex == 1) {
        filteredAppointments = appointments
            .where((appt) => appt['status'] != 'Completed')
            .toList();
      } else {
        filteredAppointments = appointments
            .where((appt) => appt['status'] == 'Completed')
            .toList();
      }
    });
  }

  Future<void> _updateRating(int appointmentId, int rating) async {
    final db = await Sqlite.db();
    await db.update('appointments', {'rating': rating}, where: 'id = ?', whereArgs: [appointmentId]);
    _fetchAppointments();
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Rating updated to $rating stars!'),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: EdgeInsets.only(
          bottom: MediaQuery.of(context).size.height - 100,
          right: 20,
          left: 20,
        ),
      ),
    );
  }
  
  String _formatDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) {
      return 'No date';
    }
    
    try {
      final date = DateTime.parse(dateString);
      return DateFormat('MMM dd, yyyy').format(date);
    } catch (e) {
      return dateString;
    }
  }

  Color _getStatusColor(String? status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Scheduled':
        return Colors.blue;
      case 'Cancelled':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }
  
  IconData _getStatusIcon(String? status) {
    switch (status) {
      case 'Completed':
        return Icons.check_circle;
      case 'Scheduled':
        return Icons.event_available;
      case 'Cancelled':
        return Icons.cancel;
      default:
        return Icons.pending;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          "My Appointments",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          indicatorWeight: 3,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: "All"),
            Tab(text: "Upcoming"),
            Tab(text: "Completed"),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchAppointments,
            tooltip: 'Refresh appointments',
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _fetchAppointments,
              child: filteredAppointments.isEmpty
                  ? _buildEmptyState()
                  : Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: ListView.builder(
                        itemCount: filteredAppointments.length,
                        itemBuilder: (context, index) {
                          final appt = filteredAppointments[index];
                          return _buildAppointmentCard(appt);
                        },
                      ),
                    ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.to(() => AddAppointmentPage(refresh: _fetchAppointments)),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("New Appointment"),
        elevation: 4,
      ),
    );
  }
  
  Widget _buildEmptyState() {
    String message;
    IconData icon;
    
    switch (_tabController.index) {
      case 1:
        message = "No upcoming appointments";
        icon = Icons.event_busy;
        break;
      case 2:
        message = "No completed appointments";
        icon = Icons.history;
        break;
      default:
        message = "No appointments found";
        icon = Icons.calendar_today;
    }
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            message,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => Get.to(() => AddAppointmentPage(refresh: _fetchAppointments)),
            icon: const Icon(Icons.add),
            label: const Text("Schedule New Appointment"),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildAppointmentCard(Map<String, dynamic> appt) {
    final bool isCompleted = appt['status'] == 'Completed';
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
        ),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: CircleAvatar(
            backgroundColor: _getStatusColor(appt['status']).withOpacity(0.2),
            child: Icon(
              _getStatusIcon(appt['status']),
              color: _getStatusColor(appt['status']),
            ),
          ),
          title: Text(
            appt['doctorname'] ?? 'Unknown Doctor',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              Row(
                children: [
                  Icon(
                    Icons.calendar_today,
                    size: 14,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(appt['date']),
                    style: TextStyle(
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: _getStatusColor(appt['status']).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  appt['status'] ?? 'Unknown',
                  style: TextStyle(
                    fontSize: 12,
                    color: _getStatusColor(appt['status']),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (appt['reason'] != null && appt['reason'].toString().isNotEmpty)
                    _buildDetailItem(
                      'Reason',
                      appt['reason'],
                      Icons.info_outline,
                    ),
                  if (isCompleted && appt['summary'] != null)
                    _buildDetailItem(
                      'Summary',
                      appt['summary'] ?? 'No summary available',
                      Icons.description,
                    ),
                  if (isCompleted && appt['prescriptions'] != null)
                    _buildDetailItem(
                      'Prescriptions',
                      appt['prescriptions'] ?? 'No prescriptions',
                      Icons.medication,
                    ),
                  if (isCompleted)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Divider(),
                        const SizedBox(height: 8),
                        const Text(
                          "Rate Your Experience",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(5, (starIndex) {
                            return GestureDetector(
                              onTap: () => _updateRating(appt['id'], starIndex + 1),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 4),
                                child: Icon(
                                  starIndex < (appt['rating'] ?? 0)
                                      ? Icons.star
                                      : Icons.star_border,
                                  color: Colors.amber,
                                  size: 32,
                                ),
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String title, String content, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: Colors.blue),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 26),
            child: Text(
              content,
              style: const TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}
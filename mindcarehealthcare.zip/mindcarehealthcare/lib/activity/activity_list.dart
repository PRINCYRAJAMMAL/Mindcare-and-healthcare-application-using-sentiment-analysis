import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';
import 'package:mindcarehealthcare/activity/activity_answers.dart';
import 'package:mindcarehealthcare/activity/add_activity.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

class ActivityList extends StatefulWidget {
  const ActivityList({super.key});

  @override
  State<ActivityList> createState() => _ActivityListState();
}

class _ActivityListState extends State<ActivityList> {
  List<Map<String, dynamic>> activities = [];
  bool isLoading = true;

  void fetchActivities() async {
    setState(() {
      isLoading = true;
    });
    
    List<Map<String, dynamic>> fetchedActivities = await Sqlite.getActivities();
    
    setState(() {
      activities = fetchedActivities;
      isLoading = false;
    });
  }

  String formatDate(String dateString) {
    try {
      // Assuming the date format in database is "yyyy-MM-dd"
      DateTime date = DateTime.parse(dateString);
      
      // Format to a more readable format (e.g., "Jan 15, 2024")
      return DateFormat.yMMMd().format(date);
    } catch (e) {
      // Return original string if parsing fails
      return dateString;
    }
  }

  @override
  void initState() {
    super.initState();
    fetchActivities();
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: primaryColor,
        title: const Text(
          "Activities",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: Colors.white),
            onPressed: () async {
              await Get.to(() => AddActivityPage());
              fetchActivities();
            },
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: primaryColor,
        onPressed: () async {
          await Get.to(() => AddActivityPage());
          fetchActivities();
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(
                color: primaryColor,
              ),
            )
          : activities.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.event_note,
                        size: 80,
                        color: primaryColor.withOpacity(0.5),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        "No activities yet",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.add),
                        label: const Text("Add Activity"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryColor,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                        ),
                        onPressed: () async {
                          await Get.to(() => AddActivityPage());
                          fetchActivities();
                        },
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  color: primaryColor,
                  onRefresh: () async {
                    fetchActivities();
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12.0),
                    itemCount: activities.length,
                    itemBuilder: (context, index) {
                      final activity = activities[index];
                      final questions = jsonDecode(activity['questions'])['questions'];
                      final formattedDate = formatDate(activity['date']);
                      
                      return Card(
                        

                        margin: const EdgeInsets.only(bottom: 16.0),
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: InkWell(
                          onTap: () => Get.to(()=> ActivityAnswersPage(activityId: activity["id"])),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 8.0),
                                  leading: CircleAvatar(
                                    backgroundColor: primaryColor,
                                    child: const Icon(
                                      Icons.event_available,
                                      color: Colors.white,
                                    ),
                                  ),
                                  title: Text(
                                    activity['name'],
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                  subtitle: Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: Text(
                                      activity['description'],
                                      style: TextStyle(
                                        color: Colors.grey[700],
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                  padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
                                  decoration: BoxDecoration(
                                    color: primaryColor.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.calendar_today,
                                        size: 16,
                                        color: primaryColor,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        formattedDate,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          color: primaryColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                ExpansionTile(
                                  tilePadding: const EdgeInsets.symmetric(horizontal: 16.0),
                                  title: Text(
                                    "Questions (${questions.length})",
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: primaryColor,
                                    ),
                                  ),
                                  leading: Icon(
                                    Icons.question_answer,
                                    color: primaryColor,
                                  ),
                                  childrenPadding: const EdgeInsets.symmetric(
                                    horizontal: 16.0,
                                    vertical: 8.0,
                                  ),
                                  expandedCrossAxisAlignment: CrossAxisAlignment.start,
                                  children: questions.map<Widget>((q) {
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: 8.0),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Icon(
                                            Icons.circle,
                                            size: 8,
                                            color: primaryColor,
                                          ),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              q,
                                              style: const TextStyle(fontSize: 15),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                                const SizedBox(height: 8),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
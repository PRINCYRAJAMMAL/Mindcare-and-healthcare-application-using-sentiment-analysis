import 'package:flutter/material.dart';
import 'package:mindcarehealthcare/main.dart';
import 'package:mindcarehealthcare/sqlite.dart';

class ShowAllActivities extends StatefulWidget {
  const ShowAllActivities({super.key});

  @override
  State<ShowAllActivities> createState() => _ShowAllActivitiesState();
}

class _ShowAllActivitiesState extends State<ShowAllActivities> {
  List<Map<String, dynamic>> activities = [];
  Map<int, Map<String, dynamic>> completedActivities = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchActivities();
  }

  Future<void> _fetchActivities() async {
    setState(() {
      isLoading = true;
    });
    
    final db = await Sqlite.db();
    final activityList = await db.query('activity');
    final questionAnswersList = await db.query(
      'questionanswers',
      where: 'userid = ?',
      whereArgs: [getid()],
    );

    Map<int, Map<String, dynamic>> completedMap = {};
    for (var qa in questionAnswersList) {
      completedMap[qa['activityid'] as int] = qa;
    }

    setState(() {
      activities = activityList;
      completedActivities = completedMap;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wellness Activities', 
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        elevation: 0,

        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchActivities,
          ),
        ],
      ),
      body: isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading activities...'),
                ],
              ),
            )
          : activities.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.sentiment_dissatisfied, size: 64, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      Text(
                        'No activities found',
                        style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchActivities,
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: ListView.builder(
                      physics: const AlwaysScrollableScrollPhysics(),
                      itemCount: activities.length,
                      itemBuilder: (context, index) {
                        final activity = activities[index];
                        final isCompleted = completedActivities.containsKey(activity['id']);
                        return ActivityTile(
                          activity: activity,
                          isCompleted: isCompleted,
                          answers: isCompleted ? completedActivities[activity['id']]!['answers'] : null,
                        );
                      },
                    ),
                  ),
                ),
    );
  }
}

class ActivityTile extends StatefulWidget {
  final Map<String, dynamic> activity;
  final bool isCompleted;
  final String? answers;

  const ActivityTile({
    super.key,
    required this.activity,
    required this.isCompleted,
    this.answers,
  });

  @override
  _ActivityTileState createState() => _ActivityTileState();
}

class _ActivityTileState extends State<ActivityTile> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    // Determine activity type and assign icon
    IconData activityIcon;
    Color activityColor;
    
    final activityType = widget.activity['type']?.toString().toLowerCase() ?? 'general';
    
    switch (activityType) {
      case 'meditation':
        activityIcon = Icons.self_improvement;
        activityColor = Colors.indigo;
        break;
      case 'exercise':
        activityIcon = Icons.fitness_center;
        activityColor = Colors.orange;
        break;
      case 'journal':
        activityIcon = Icons.book;
        activityColor = Colors.teal;
        break;
      case 'breathing':
        activityIcon = Icons.air;
        activityColor = Colors.blue;
        break;
      default:
        activityIcon = Icons.psychology;
        activityColor = Colors.purple;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16.0),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: widget.isCompleted ? Colors.green.shade200 : Colors.transparent,
          width: widget.isCompleted ? 1.5 : 0,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          if (widget.isCompleted) {
            setState(() {
              _isExpanded = !_isExpanded;
            });
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: activityColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      activityIcon,
                      color: activityColor,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                widget.activity['name'],
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            if (widget.isCompleted)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.green.shade100,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.check_circle, color: Colors.green.shade700, size: 16),
                                    const SizedBox(width: 4),
                                    Text(
                                      'Completed',
                                      style: TextStyle(
                                        color: Colors.green.shade700,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.activity['description'],
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              if (_isExpanded && widget.isCompleted) ...[
                const Divider(height: 24),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Your Responses',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.answers ?? 'No responses recorded',
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ],
              if (widget.isCompleted)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                    onPressed: () {
                      setState(() {
                        _isExpanded = !_isExpanded;
                      });
                    },
                    icon: Icon(
                      _isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                      size: 18,
                    ),
                    label: Text(_isExpanded ? 'Hide Details' : 'View Details'),
                    style: TextButton.styleFrom(
                      foregroundColor: Theme.of(context).primaryColor,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
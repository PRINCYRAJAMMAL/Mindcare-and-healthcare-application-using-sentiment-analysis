import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart'; // For date formatting

class ActivityAnswersPage extends StatefulWidget {
  final int activityId;
  const ActivityAnswersPage({super.key, required this.activityId});

  @override
  _ActivityAnswersPageState createState() => _ActivityAnswersPageState();
}

class _ActivityAnswersPageState extends State<ActivityAnswersPage> {
  List<Map<String, dynamic>> _answers = [];
  Map<int, TextEditingController> _feedbackControllers = {};
  bool _isLoading = true;
  
  @override
  void initState() {
    super.initState();
    _fetchAnswers();
  }
  
  @override
  void dispose() {
    // Dispose all controllers
    _feedbackControllers.forEach((_, controller) => controller.dispose());
    super.dispose();
  }

  Future<void> _fetchAnswers() async {
    setState(() {
      _isLoading = true;
    });
    
    final _database = await Sqlite.db();
    
    final List<Map<String, dynamic>> results = await _database.rawQuery(
      '''
      SELECT qa.*, u.name AS username, u.id AS user_id FROM questionanswers qa
      JOIN user u ON qa.userid = u.id
      WHERE qa.activityid = ?
      ORDER BY qa.id DESC
      ''',
      [widget.activityId],
    );
    
    // Create controllers for each answer
    for (var answer in results) {
      final answerId = answer['id'];
      _feedbackControllers[answerId] = TextEditingController(text: answer['feedback'] ?? '');
    }
    
    setState(() {
      _answers = results;
      _isLoading = false;
    });
  }

  Future<void> _saveFeedback(int answerId, String feedback) async {
    try {
      final _database = await Sqlite.db();
      
      await _database.update(
        'questionanswers',
        {'feedback': feedback},
        where: 'id = ?',
        whereArgs: [answerId],
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Feedback saved successfully'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 2),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving feedback: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  String _formatDate(String timestamp) {
    try {
      final DateTime dateTime = DateTime.parse(timestamp);
      return DateFormat('MMM d, yyyy • h:mm a').format(dateTime);
    } catch (e) {
      return timestamp; // Fallback to original value if parsing fails
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Activity Responses"),
        elevation: 0,
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _fetchAnswers,
            tooltip: 'Refresh answers',
          )
        ],
      ),
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : _answers.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.inbox_outlined,
                        size: 80,
                        color: Colors.grey.shade400,
                      ),
                      SizedBox(height: 16),
                      Text(
                        "No responses found",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey.shade700,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        "Check back later for new responses",
                        style: TextStyle(
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: _answers.length,
                  itemBuilder: (context, index) {
                    final answer = _answers[index];
                    final answerId = answer['id'];
                    final List<dynamic> decodedAnswers = jsonDecode(answer['answers']);
                    
                    return Card(
                      margin: EdgeInsets.only(bottom: 16),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          // User info header
                          Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Theme.of(context).primaryColor.withOpacity(0.1),
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(12),
                                topRight: Radius.circular(12),
                              ),
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: Theme.of(context).primaryColor,
                                  child: Text(
                                    answer['username'][0].toUpperCase(),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        answer['username'],
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        _formatDate(answer['created_at'] ?? answerId.toString()),
                                        style: TextStyle(
                                          color: Colors.grey.shade700,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Icon(Icons.keyboard_arrow_down),
                              ],
                            ),
                          ),
                          
                          // Expandable questions and answers
                          ExpansionTile(
                            title: Text(
                              "Responses (${decodedAnswers.length})",
                              style: TextStyle(fontWeight: FontWeight.w500),
                            ),
                            childrenPadding: EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            children: decodedAnswers.map<Widget>((qna) {
                              return Container(
                                margin: EdgeInsets.only(bottom: 12),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey.shade200),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                padding: EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Q: ${qna['question']}",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      "A: ${qna['answer']}",
                                      style: TextStyle(
                                        color: Colors.blueGrey[700],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          ),
                          
                          // Feedback section
                          Padding(
                            padding: EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Feedback",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                SizedBox(height: 8),
                                TextField(
                                  controller: _feedbackControllers[answerId],
                                  maxLines: 3,
                                  decoration: InputDecoration(
                                    hintText: "Provide feedback on this response...",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide: BorderSide(color: Colors.grey.shade300),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide: BorderSide(
                                        color: Theme.of(context).primaryColor,
                                        width: 2,
                                      ),
                                    ),
                                    filled: true,
                                    fillColor: Colors.grey.shade50,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: ElevatedButton.icon(
                                    onPressed: () {
                                      _saveFeedback(
                                        answerId, 
                                        _feedbackControllers[answerId]!.text,
                                      );
                                    },
                                    icon: Icon(Icons.save),
                                    label: Text("Save Feedback"),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Theme.of(context).primaryColor,
                                      foregroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:mindcarehealthcare/sqlite.dart';

class ViewUsers extends StatefulWidget {
  const ViewUsers({super.key});

  @override
  State<ViewUsers> createState() => _ViewUsersState();
}

class _ViewUsersState extends State<ViewUsers> {
  List<Map<String, dynamic>> users = []; // To store the fetched users

  @override
  void initState() {
    super.initState();

    // Fetch the users and update the state
    Sqlite.getUsers().then((userList) {
      setState(() {
        users = List<Map<String, dynamic>>.from(userList); // Store the users
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Users'),
      ),
      body: users.isEmpty
          ? const Center(child: CircularProgressIndicator()) // Show loading indicator while fetching
          : ListView.builder(
              itemCount: users.length,
              itemBuilder: (context, index) {
                var user = users[index]; // Get user at current index
                return Card(
                  margin: const EdgeInsets.all(10),
                  child: ListTile(
                    title: Text(user['name'] ?? 'No Name'),
                    subtitle: Text('Type: ${user['type']}, \n UserID: ${user['userid']} \n Password : ${user["password"]}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () {
                        // You can add delete functionality here if needed
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mindcarehealthcare/sqlite.dart';
import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:intl/intl.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class UserSummaryReport extends StatefulWidget {
  final String userId;

  const UserSummaryReport({Key? key, required this.userId}) : super(key: key);

  @override
  State<UserSummaryReport> createState() => _UserSummaryReportState();
}

class _UserSummaryReportState extends State<UserSummaryReport> {
  bool isLoading = true;
  String summaryText = "";
  Map<String, dynamic> userData = {};
  List<Map<String, dynamic>> userAppointments = [];
  List<Map<String, dynamic>> userActivities = [];
  List<Map<String, dynamic>> userPrescriptions = [];

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    try {
      final database = await Sqlite.db();

      // Fetch user details
      final List<Map<String, dynamic>> userResult = await database.query(
        'user',
        where: 'id = ?',
        whereArgs: [widget.userId],
      );

      if (userResult.isNotEmpty) {
        userData = userResult.first;
      }

      // Fetch appointments
      userAppointments = await database.query(
        'appointments',
        where: 'userid = ?',
        whereArgs: [widget.userId],
      );

      // Fetch activity responses
      final List<Map<String, dynamic>> activityResponses = await database.query(
        'questionanswers',
        where: 'userid = ?',
        whereArgs: [widget.userId],
      );

      // Get activity details for each response
      for (var response in activityResponses) {
        final activityId = response['activityid'];
        final List<Map<String, dynamic>> activityDetails = await database.query(
          'activity',
          where: 'id = ?',
          whereArgs: [activityId],
        );
        
        if (activityDetails.isNotEmpty) {
          userActivities.add({
            ...response,
            'activityDetails': activityDetails.first,
          });
        }
      }

      // Fetch prescriptions
      userPrescriptions = await database.query(
        'prescription',
        where: 'userid = ?',
        whereArgs: [widget.userId],
      );

      // Generate the AI summary
      await generateAiSummary();

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
        summaryText = "Error generating report: $e";
      });
    }
  }

  Future<void> generateAiSummary() async {
    // Format data for the Gemini API
    final Map<String, dynamic> formattedData = {
      'user': userData,
      'appointments': userAppointments,
      'activities': userActivities,
    };

    // Construct the prompt for Gemini
    final String prompt = """
    Generate a comprehensive health summary report for a patient based on the following data:
    
    ${jsonEncode(formattedData)}
    
    Please analyze this data and create a user-friendly health summary with the following sections:
    1. Personal Overview - Brief introduction of the patient
    2. Appointment Summary - Key insights from past appointments
    3. Activity Engagement - Analysis of activities completed and their impact
    4. Medication Adherence - Overview of prescriptions and adherence patterns
    5. Progress Insights - Overall progress and trends in health metrics
    6. Recommendations - Personalized recommendations based on all data
    
    Use a friendly, encouraging tone while maintaining medical professionalism. 
    Format the report in a clear, readable structure with appropriate headings and bullet points.
    dont use md
    """;

    try {
      // Replace with your actual Gemini API endpoint and key
      final response = await http.post(
        Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyDUqzRSnfxX-7Z3hKuysNX9rk-LD9Bwvdo'),
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': 'AIzaSyDUqzRSnfxX-7Z3hKuysNX9rk-LD9Bwvdo', // Replace with your actual API key
        },
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        // Extract the generated text from the Gemini API response
        final String generatedText = responseData['candidates'][0]['content']['parts'][0]['text'];
        
        setState(() {
          summaryText = generatedText;
        });
      } else {
        throw Exception('Failed to generate summary: ${response.statusCode}');
      }
    } catch (e) {
      // Fallback to a template-based summary if AI generation fails
      generateTemplateSummary();
    }
  }

  // Fallback method to generate a basic summary if the API call fails
  void generateTemplateSummary() {
    final String userName = userData['name'] ?? 'Patient';
    final int appointmentCount = userAppointments.length;
    final int completedActivities = userActivities.where((a) => a['completed'] == 1).length;
    final int prescriptionCount = userPrescriptions.length;
    
    setState(() {
      summaryText = """
# Health Summary Report for $userName

## Personal Overview
$userName has engaged with our healthcare platform with a total of $appointmentCount appointments, $completedActivities completed wellness activities, and $prescriptionCount medications tracked.

## Appointment Summary
The patient has attended ${userAppointments.where((a) => a['status'] == 'completed').length} appointments, with ${userAppointments.where((a) => a['status'] == 'scheduled').length} upcoming consultations.

## Activity Engagement
$userName has completed $completedActivities wellness activities, demonstrating commitment to improving their health.

## Medication Adherence
Currently managing $prescriptionCount medications as prescribed by healthcare providers.

## Recommendations
Continue regular check-ups and maintain consistent engagement with prescribed wellness activities.
      """;
    });
  }

  @override
  Widget build(BuildContext context) {
    final String userName = userData['name'] ?? 'User';
    final completedAppointments = userAppointments.where((a) => a['status'] == 'completed').length;
    final totalAppointments = userAppointments.length;
    final completedActivities = userActivities.where((a) => a['completed'] == 1).length;
    final totalActivities = userActivities.length;
    
    // Calculate percentages for progress indicators
    final double appointmentPercentage = totalAppointments > 0 ? 
        completedAppointments / totalAppointments : 0.0;
    final double activityPercentage = totalActivities > 0 ? 
        completedActivities / totalActivities : 0.0;
    final double medicationPercentage = userPrescriptions.length > 0 ? 0.85 : 0.0; // Placeholder value

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        title: Text(
          'Report',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    color: Colors.blue[700],
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Generating your health report...',
                    style: TextStyle(
                      color: Colors.blue[700],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            )
          : SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // User profile header with gradient background
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Colors.blue[600]!, Colors.blue[800]!],
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                    ),
                    padding: EdgeInsets.fromLTRB(20, 30, 20, 30),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                              child: CircleAvatar(
                                radius: 35,
                                backgroundColor: Colors.blue[100],
                                child: Text(
                                  userName.isNotEmpty ? userName.substring(0, 1).toUpperCase() : 'U',
                                  style: TextStyle(
                                    fontSize: 30,
                                    color: Colors.blue[800],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 20),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    userName,
                                    style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    'Report: ${DateFormat('MMMM d, yyyy').format(DateTime.now())}',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.9),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 25),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
         
                            _buildCircularProgressIndicator(
                              'Activities',
                              activityPercentage,
                              Colors.white,
                              '$completedActivities/$totalActivities',
                            ),
            
                          ],
                        ),
                      ],
                    ),
                  ),
                  
                  // Health insights section
                  Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Health Insights',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[900],
                          ),
                        ),
                        SizedBox(height: 20),
                        _buildInsightCard(
                          title: 'Progress Overview',
                          content: 'Your health journey shows consistent improvement across metrics. Keep up the good work!',
                          icon: Icons.trending_up,
                          color: Colors.green,
                        ),
                        SizedBox(height: 15),
                        _buildInsightCard(
                          title: 'Next Steps',
                          content: 'Focus on completing your daily activities and don\'t miss your upcoming appointments.',
                          icon: Icons.next_plan,
                          color: Colors.orange,
                        ),
                      ],
                    ),
                  ),
                  
                  // AI-Generated Report Section
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          spreadRadius: 0,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.all(20),
                          child: Row(
                            children: [
                              Icon(
                                Icons.smart_toy_outlined,
                                color: Colors.blue[700],
                              ),
                              SizedBox(width: 10),
                              Text(
                                'AI Health Summary',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Divider(height: 1, thickness: 1, color: Colors.grey[200]),
                        // Fix: Wrap the Markdown widget with a container of definite height
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.all(20),
                          child: 
                          true?
                          Text(summaryText):
                          
                          MarkdownBody(
                            data: summaryText,
                            styleSheet: MarkdownStyleSheet(
                              h1: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[900],
                              ),
                              h2: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[800],
                              ),
                              h3: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[700],
                              ),
                              p: TextStyle(fontSize: 16, height: 1.5, color: Colors.black87),
                              strong: TextStyle(fontWeight: FontWeight.bold),
                              blockquote: TextStyle(
                                fontStyle: FontStyle.italic,
                                color: Colors.grey[700],
                              ),
                              listBullet: TextStyle(fontSize: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Detailed metrics section
                  Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Health Metrics',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[900],
                          ),
                        ),
                        SizedBox(height: 20),
                        _buildMetricsGrid(),
                      ],
                    ),
                  ),
                  

                ],
              ),
            ),
    );
  }

  Widget _buildCircularProgressIndicator(
    String title, 
    double percentage, 
    Color color,
    String centerText,
  ) {
    return Column(
      children: [
        CircularPercentIndicator(
          radius: 35,
          lineWidth: 5,
          percent: percentage.clamp(0.0, 1.0),
          center: Text(
            centerText,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          progressColor: Colors.white,
          backgroundColor: Colors.white.withOpacity(0.3),
          circularStrokeCap: CircularStrokeCap.round,
        ),
        SizedBox(height: 8),
        Text(
          title,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildInsightCard({
    required String title,
    required String content,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 0,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: color,
              size: 25,
            ),
          ),
          SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  content,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricsGrid() {
    final int completedAppointments = userAppointments.where((a) => a['status'] == 'completed').length;
    final int upcomingAppointments = userAppointments.where((a) => a['status'] == 'scheduled').length;
    final int completedActivities = userActivities.where((a) => a['completed'] == 1).length;
    
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 15,
      mainAxisSpacing: 15,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [

        _buildMetricCard(
          'Activities',
          '$completedActivities completed',
          Icons.directions_run,
          Colors.green[600]!,
        ),

        _buildMetricCard(
          'Overall Progress',
          'On track',
          Icons.trending_up,
          Colors.orange[600]!,
        ),
      ],
    );
  }

  Widget _buildMetricCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 0,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: color,
              size: 22,
            ),
          ),
          SizedBox(height: 15),
          Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
              fontSize: 16,
            ),
          ),
          SizedBox(height: 5),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
              height: 1.3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(String text, IconData icon, Color color) {
    return ElevatedButton(
      onPressed: () {},
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        elevation: 0,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 18),
          SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
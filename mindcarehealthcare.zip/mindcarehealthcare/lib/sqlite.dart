import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:async';

class Sqlite {
  static final Sqlite _instance = Sqlite._internal();
  static Database? _database;

  factory Sqlite() {
    return _instance;
  }

  Sqlite._internal();

  static Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'mentalcare.db');
    
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
      singleInstance: true
    );
  }

  static Future<Database> db() async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  static Future<void> _onCreate(Database db, int version) async {
    // User table
    await db.execute('''
      CREATE TABLE user (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        address TEXT,
        type TEXT,
        userid TEXT UNIQUE,
        password TEXT,
        points INTEGER DEFAULT 0
      )
    ''');

      await db.insert('user', {
    'name': 'John Doe',
    'address': '123 Main St, City',
    'type': 'Patient',
    'userid': 'user',
    'password': 'user',
  });

  await db.insert('user', {
    'name': 'Dr. Smith',
    'address': '456 Medical Rd, City',
    'type': 'Doctor',
    'userid': 'doc',
    'password': 'doc',
  });

    // Holidays table
    await db.execute('''
      CREATE TABLE holidays (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT
      )
    ''');

        await db.execute('''
      CREATE TABLE appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        userid INTEGER,
        username TEXT,
        doctorid INTEGER,
        doctorname TEXT,
        status TEXT,
        summary TEXT,
        prescriptions TEXT,
        prescriptiontimings TEXT,
        reward INTEGER,
        reason TEXT,
        completeddate TEXT,
        rating INTEGER,
        type TEXT,
        time TEXT
      )
    ''');

    // Activity table
    await db.execute('''
      CREATE TABLE activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        description TEXT,
        questions TEXT,
        date TEXT,
        points INTEGER
      )
    ''');

    // QuestionAnswers table
    await db.execute('''
      CREATE TABLE questionanswers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userid TEXT,
        feedback TEXT,
        activityid INTEGER,
        activityname TEXT,
        completed INTEGER,
        answers TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    ''');

    await db.execute('''
      CREATE TABLE prescription (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userid TEXT,
        reportid INTEGER,
        name TEXT,
        appointmentid INT
        timings TEXT
      )
    ''');
  }

  // User CRUD operations
  static Future<int> insertUser(Map<String, dynamic> user) async {
    Database db = await Sqlite.db();
    return await db.insert('user', user);
  }

  static Future<List<Map<String, dynamic>>> getUsers() async {
    Database db = await Sqlite.db();
    return await db.query('user');
  }

    static Future<List<Map<String, dynamic>>> getPatients() async {
    Database db = await Sqlite.db();
    return await db.query('user',
    where: "type = ?",
    whereArgs: ["Patient"]);
  }

      static Future<List<Map<String, dynamic>>> getDoctors() async {
    Database db = await Sqlite.db();
    return await db.query('user',
    where: "type = ?",
    whereArgs: ["Doctor"]);
  }

  static Future<Map<String, dynamic>?> getUserById(int id) async {
    Database db = await Sqlite.db();
    List<Map<String, dynamic>> result = await db.query(
      'user',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return result.isNotEmpty ? result.first : null;
  }

  static Future<Map<String, dynamic>?> getUserByUserId(String userId) async {
    Database db = await Sqlite.db();
    List<Map<String, dynamic>> result = await db.query(
      'user',
      where: 'userid = ?',
      whereArgs: [userId],
      limit: 1,
    );
    return result.isNotEmpty ? result.first : null;
  }

  static Future<int> updateUser(Map<String, dynamic> user) async {
    Database db = await Sqlite.db();
    return await db.update(
      'user',
      user,
      where: 'id = ?',
      whereArgs: [user['id']],
    );
  }

  static Future<int> deleteUser(int id) async {
    Database db = await Sqlite.db();
    return await db.delete(
      'user',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Holidays CRUD operations
  static Future<int> insertHoliday(Map<String, dynamic> holiday) async {
    Database db = await Sqlite.db();
    return await db.insert('holidays', holiday);
  }

  static Future<List<Map<String, dynamic>>> getHolidays() async {
    Database db = await Sqlite.db();
    return await db.query('holidays');
  }

  static Future<int> deleteHoliday(int id) async {
    Database db = await Sqlite.db();
    return await db.delete(
      'holidays',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Activity CRUD operations
  static Future<int> insertActivity(Map<String, dynamic> activity) async {
    Database db = await Sqlite.db();
    return await db.insert('activity', activity);
  }

  static Future<List<Map<String, dynamic>>> getActivities() async {
    Database db = await Sqlite.db();
    return await db.query('activity');
  }

  static Future<Map<String, dynamic>?> getActivityById(int id) async {
    Database db = await Sqlite.db();
    List<Map<String, dynamic>> result = await db.query(
      'activity',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return result.isNotEmpty ? result.first : null;
  }

  static Future<int> updateActivity(Map<String, dynamic> activity) async {
    Database db = await Sqlite.db();
    return await db.update(
      'activity',
      activity,
      where: 'id = ?',
      whereArgs: [activity['id']],
    );
  }

  static Future<int> deleteActivity(int id) async {
    Database db = await Sqlite.db();
    return await db.delete(
      'activity',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // QuestionAnswers CRUD operations
  static Future<int> insertQuestionAnswers(Map<String, dynamic> qa) async {
    Database db = await Sqlite.db();
    return await db.insert('questionanswers', qa);
  }

  static Future<List<Map<String, dynamic>>> getQuestionAnswers() async {
    Database db = await Sqlite.db();
    return await db.query('questionanswers');
  }

  static Future<List<Map<String, dynamic>>> getQuestionAnswersByUserId(String userId) async {
    Database db = await Sqlite.db();
    return await db.query(
      'questionanswers',
      where: 'userid = ?',
      whereArgs: [userId],
    );
  }

  static Future<int> updateQuestionAnswers(Map<String, dynamic> qa) async {
    Database db = await Sqlite.db();
    return await db.update(
      'questionanswers',
      qa,
      where: 'id = ?',
      whereArgs: [qa['id']],
    );
  }

  // Report CRUD operations
  static Future<int> insertReport(Map<String, dynamic> report) async {
    Database db = await Sqlite.db();
    return await db.insert('report', report);
  }

  static Future<List<Map<String, dynamic>>> getReports() async {
    Database db = await Sqlite.db();
    return await db.query('report');
  }

  static Future<Map<String, dynamic>?> getReportById(int id) async {
    Database db = await Sqlite.db();
    List<Map<String, dynamic>> result = await db.query(
      'report',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return result.isNotEmpty ? result.first : null;
  }

  // Prescription CRUD operations
  static Future<int> insertPrescription(Map<String, dynamic> prescription) async {
    Database db = await Sqlite.db();
    return await db.insert('prescription', prescription);
  }

  static Future<List<Map<String, dynamic>>> getPrescriptions() async {
    Database db = await Sqlite.db();
    return await db.query('prescription');
  }

  static Future<List<Map<String, dynamic>>> getPrescriptionsByUserId(String userId) async {
    Database db = await Sqlite.db();
    return await db.query(
      'prescription',
      where: 'userid = ?',
      whereArgs: [userId],
    );
  }

  static Future<List<Map<String, dynamic>>> getPrescriptionsByReportId(int reportId) async {
    Database db = await Sqlite.db();
    return await db.query(
      'prescription',
      where: 'reportid = ?',
      whereArgs: [reportId],
    );
  }

  static Future<int> updatePrescription(Map<String, dynamic> prescription) async {
    Database db = await Sqlite.db();
    return await db.update(
      'prescription',
      prescription,
      where: 'id = ?',
      whereArgs: [prescription['id']],
    );
  }

  static Future<int> deletePrescription(int id) async {
    Database db = await Sqlite.db();
    return await db.delete(
      'prescription',
      where: 'id = ?',
      whereArgs: [id],
    );
  }


  static Future<void> incrementUserPoints(int userId, int pointsToAdd) async {
  Database db = await Sqlite.db();

  final List<Map<String, dynamic>> result = await db.query(
    'user',
    columns: ['points'],
    where: 'id = ?',
    whereArgs: [userId],
  );
  
  if (result.isNotEmpty) {
    final int currentPoints = result.first['points'] ?? 0;
    final int newPoints = currentPoints + pointsToAdd;
    
    // Update the points
    await db.update(
      'user',
      {'points': newPoints},
      where: 'id = ?',
      whereArgs: [userId],
    );
  } else {
    throw Exception('User with ID $userId not found');
  }
}


}
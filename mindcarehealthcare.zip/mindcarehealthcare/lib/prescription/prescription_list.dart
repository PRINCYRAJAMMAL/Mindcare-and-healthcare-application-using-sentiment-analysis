import 'package:flutter/material.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';



class PrescriptionList extends StatefulWidget {
  @override
  _PrescriptionPageState createState() => _PrescriptionPageState();
}

class _PrescriptionPageState extends State<PrescriptionList> {

  List<Map<String, dynamic>> _prescriptions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchPrescriptions();
  }



  Future<void> _fetchPrescriptions() async {
     Database _database = await Sqlite.db();
    final List<Map<String, dynamic>> data = await _database.query('appointments');
    setState(() {
      _prescriptions = data;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Prescriptions'),
        centerTitle: true,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _prescriptions.isEmpty
              ? Center(child: Text("No Prescriptions Found!", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)))
              : ListView.builder(
                  padding: EdgeInsets.all(16.0),
                  itemCount: _prescriptions.length,
                  itemBuilder: (context, index) {
                    final item = _prescriptions[index];
                    return PrescriptionCard(
                      doctorName: item['doctorname'],
                      prescription: item['prescriptions'] ?? "Prescription Not Provided",
                      timings: item['prescriptiontimings'] ?? "Prescription Not Provided",
                    );
                  },
                ),
    );
  }
}

class PrescriptionCard extends StatelessWidget {
  final String doctorName;
  final String prescription;
  final String timings;

  const PrescriptionCard({
    required this.doctorName,
    required this.prescription,
    required this.timings,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "👨‍⚕️ Dr. $doctorName",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blueAccent),
            ),
            SizedBox(height: 8),
            Text(
              "🕒 Timings: $timings",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black87),
            ),
            SizedBox(height: 8),
            Text(
              "💊 Prescription: $prescription",
              style: TextStyle(fontSize: 14, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/route_manager.dart';
import 'package:localstorage/localstorage.dart';
import 'package:mindcarehealthcare/activity/activity_list.dart';
import 'package:mindcarehealthcare/ai_summary.dart';
import 'package:mindcarehealthcare/appointments/doctor_appointments_page.dart';
import 'package:mindcarehealthcare/login/login_page.dart';
import 'package:mindcarehealthcare/patient/profile.dart';
import 'package:mindcarehealthcare/sqlite.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:google_fonts/google_fonts.dart';

class DoctorHome extends StatefulWidget {
  const DoctorHome({super.key});

  @override
  State<DoctorHome> createState() => _DoctorHomeState();
}

class _DoctorHomeState extends State<DoctorHome> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  List<Map<String, dynamic>> patients = [];
  List<DateTime> holidays = [];
  bool isLoading = true;

  void _addPatient() {
    setState(() {
      patients.add({"name": "New Patient", "address": "Unknown Address"});
    });
  }

  void _addHoliday(DateTime date) {
    Sqlite.insertHoliday({
      "date": date.toIso8601String()
    });
    
    setState(() {
      if (!holidays.contains(date)) {
        holidays.add(date);
      }
    });

    Fluttertoast.showToast(
      msg: "Holiday Added Successfully",
      backgroundColor: Colors.green.shade700,
      textColor: Colors.white,
      fontSize: 16.0,
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  void getPatient() {
    setState(() {
      isLoading = true;
    });
    
    Sqlite.getPatients().then((v) {
      setState(() {
        patients = v;
        isLoading = false;
      });
    });
  }

  void getHolidays() {
    Sqlite.getHolidays().then((v) {
      v.forEach((v) {
        DateTime d = DateTime.parse(v["date"]);
        holidays.add(d);
      });
      setState(() {});
    });
  }

  int activities = 0;


  void getActivitiesCount(){

    Sqlite.getActivities().then((v){
      activities = v.length;

      setState(() {
        
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getPatient();
    getHolidays();

    getActivitiesCount();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Theme.of(context).primaryColor,
          title: Text(
            "Doctor Dashboard",
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.white
            ),
          ),
          leading: IconButton(
            icon: const Icon(Icons.calendar_month_rounded, color: Colors.white),
            onPressed: () {
              _scaffoldKey.currentState?.openDrawer();
            },
          ),
          actions: [
            // IconButton(
            //   onPressed: () {},
            //   icon: const Icon(Icons.notifications_outlined, color: Colors.white),
            //   tooltip: 'Notifications',
            // ),
            TextButton.icon(
              onPressed: () async {

                localStorage.clear();
                Get.to(()=>LoginPage());
            
              },
              icon: const Icon(Icons.logout, color: Colors.white),
              label: Text(
                "Logout",
                style: GoogleFonts.poppins(
                  color: Colors.white, 
                  fontWeight: FontWeight.w500
                ),
              ),
            ),
          ],
        ),
        drawer: DoctorDrawer(
          holidays: holidays,
          addHoliday: _addHoliday,
        ),
        body: isLoading 
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    color: Theme.of(context).primaryColor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Welcome back, Doctor",
                          style: GoogleFonts.poppins(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "You have ${patients.length} patients in your care",
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            color: Colors.white.withOpacity(0.9),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Stats Cards
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Expanded(
                          child: _buildStatCard(
                            context,
                            title: "Activities",
                            value: activities.toString(), 
                            icon: Icons.calendar_today,
                            color: Colors.blue,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildStatCard(
                            context,
                            title: "Holidays",
                            value: "${holidays.length}",
                            icon: Icons.beach_access,
                            color: Colors.orange,
                          ),
                        ),
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                      
                          ElevatedButton(onPressed: () async {
                      
                               await  Get.to(()=>Profile());
                              getActivitiesCount();
                      
                          }, child: Text("Profile")),
                      
                          SizedBox(width: 20,),
                      
                      
                          ElevatedButton(onPressed: () async {
                      
                               await  Get.to(()=>ActivityList());
                              getActivitiesCount();
                      
                          }, child: Text("Activity")),
                      
                          SizedBox(width: 20,),
                      
                          ElevatedButton(onPressed: (){
                      
                            Get.to(()=> DoctorAppointmentsPage());
                      
                          }, child: Text("Appointments"))
                      
                        ],
                      ),
                    ),
                  ),
                  
                  // Patient List Section
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Patient List",
                          style: GoogleFonts.poppins(
                            fontSize: 18, 
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        // TextButton.icon(
                        //   onPressed: _addPatient,
                        //   icon: const Icon(Icons.person_add, size: 18),
                        //   label: const Text("Add New"),
                        //   style: TextButton.styleFrom(
                        //     foregroundColor: Colors.indigo.shade800,
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                  
                  patients.isEmpty 
                    ? Center(
                        child: Column(
                          children: [
                            const SizedBox(height: 32),
                            Icon(
                              Icons.people_outline,
                              size: 64,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "No patients yet",
                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: patients.length,
                        itemBuilder: (context, index) {
                          return Card(
                            elevation: 1,
                            margin: const EdgeInsets.only(bottom: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: ListTile(
                              onTap: () {
                                Get.to(()=>UserSummaryReport(userId: patients[index]["id"].toString()));
                              },

                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16, 
                                vertical: 8
                              ),
                              leading: CircleAvatar(
                                backgroundColor: Colors.indigo.shade100,
                                child: Text(
                                  patients[index]["name"]?.substring(0, 1) ?? "P",
                                  style: TextStyle(
                                    color: Colors.indigo.shade800,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              title: Text(
                                patients[index]["name"]!,
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                              ),
                              subtitle: Text(
                                patients[index]["address"]!,
                                style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              trailing: IconButton(
                                icon: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 18,
                                  color: Colors.indigo.shade400,
                                ),
                                onPressed: () {
                                  // View patient details
                                },
                              ),
                            ),
                          );
                        },
                      ),
                ],
              ),
            ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: getPatient,
          backgroundColor: Theme.of(context).primaryColor,
          icon: const Icon(Icons.refresh, color: Colors.white,),
          label: const Text("Refresh", style: TextStyle(color: Colors.white),),
        ),
      ),
    );
  }
  
  Widget _buildStatCard(BuildContext context, {
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------- DoctorDrawer Widget ----------------
class DoctorDrawer extends StatefulWidget {
  final List<DateTime> holidays;
  final Function(DateTime) addHoliday;

  const DoctorDrawer({super.key, required this.holidays, required this.addHoliday});

  @override
  State<DoctorDrawer> createState() => _DoctorDrawerState();
}

class _DoctorDrawerState extends State<DoctorDrawer> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.of(context).size.width * 0.85,
      backgroundColor: Colors.white,
      child: Column(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Calendar",
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  "Manage your schedule and holidays",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(
                      Icons.circle,
                      size: 12,
                      color: Colors.redAccent.shade400,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Holidays",
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: TableCalendar(
              firstDay: DateTime(2020),
              lastDay: DateTime(2030),
              focusedDay: _focusedDay,
              calendarFormat: _calendarFormat,
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              holidayPredicate: (day) {
                return widget.holidays.any((holiday) => isSameDay(holiday, day));
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              },
              onFormatChanged: (format) {
                setState(() {
                  _calendarFormat = format;
                });
              },
              calendarStyle: CalendarStyle(
                holidayTextStyle: const TextStyle(
                  color: Colors.white, 
                  fontWeight: FontWeight.bold
                ),
                holidayDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.redAccent.shade400,
                ),
                todayDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.blue.shade400,
                ),
                selectedDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.indigo.shade800,
                ),
                weekendTextStyle: TextStyle(color: Colors.red.shade300),
              ),
              headerStyle: HeaderStyle(
                titleTextStyle: GoogleFonts.poppins(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
                formatButtonTextStyle: GoogleFonts.poppins(),
                leftChevronIcon: Icon(Icons.chevron_left, color: Theme.of(context).primaryColor),
                rightChevronIcon: Icon(Icons.chevron_right, color: Theme.of(context).primaryColor),
              ),
              daysOfWeekStyle: DaysOfWeekStyle(
                weekdayStyle: GoogleFonts.poppins(
                  fontWeight: FontWeight.w600, 
                  fontSize: 12
                ),
                weekendStyle: GoogleFonts.poppins(
                  fontWeight: FontWeight.w600, 
                  fontSize: 12, 
                  color: Colors.red.shade300
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                widget.addHoliday(_selectedDay);
                setState(() {});
              },
              icon: const Icon(Icons.beach_access),
              label: Text(
                "Mark as Holiday",
                style: GoogleFonts.poppins(fontWeight: FontWeight.w500),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent.shade400,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
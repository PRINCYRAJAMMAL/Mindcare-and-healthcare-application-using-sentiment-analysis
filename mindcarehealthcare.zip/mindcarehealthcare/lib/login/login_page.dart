import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:localstorage/localstorage.dart';
import 'package:mindcarehealthcare/data/view_users.dart';
import 'package:mindcarehealthcare/doctor/doctor_home.dart';
import 'package:mindcarehealthcare/patient/patient_home.dart';

import 'package:mindcarehealthcare/signup/signup_page.dart';
import 'package:mindcarehealthcare/sqlite.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _usernameController = TextEditingController(text: "user");
  final TextEditingController _passwordController = TextEditingController(text: "user");
  bool _isLoading = false;
  bool _obscurePassword = true;

  void _login() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final data = await Sqlite.getUserByUserId(_usernameController.text.trim());

      if (data == null) {
        Fluttertoast.showToast(
          msg: "User not found. Please check your credentials.",
          backgroundColor: Colors.red,
          textColor: Colors.white,
        );
      } else {
        if (data["password"] == _passwordController.text) {
          Fluttertoast.showToast(
            msg: "Successfully logged in as ${data["type"]}",
            backgroundColor: Colors.green,
            textColor: Colors.white,
          );

            localStorage.setItem("user", json.encode(data));
          // Navigate based on user type
          if (data["type"] == "Doctor") {
            localStorage.setItem("id", data["id"].toString());

            Get.offAll(() => DoctorHome());
          } else {
            // Assuming you'll create a PatientHome page

            localStorage.setItem("id", data["id"].toString());
            localStorage.setItem("name", data["name"].toString());


            Get.offAll(() => PatientHome());
          }
        } else {
          Fluttertoast.showToast(
            msg: "Incorrect password",
            backgroundColor: Colors.red,
            textColor: Colors.white,
          );
        }
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Login error: ${e.toString()}",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }


  void checkLogin(){
        if(localStorage.getItem("user")!=null){
      var data = json.decode(localStorage.getItem("user")!);


       if (data["type"] == "Doctor") {
            Get.to(() => DoctorHome());
          } else {
            // Assuming you'll create a PatientHome page
            Get.to(() => PatientHome());
          }
    }
  }


  @override
  void initState(){
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 40),
                  
                  // App logo
                  GestureDetector(
                    onTap: () {
                      Get.to(()=> ViewUsers());
                    },
                    child: Icon(
                      Icons.health_and_safety,
                      size: 80,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Welcome text
                  Text(
                    "Welcome",
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  
                  const SizedBox(height: 8),
                  
                  Text(
                    "Sign in to continue",
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  
                  const SizedBox(height: 40),
                  
                  // Username field
                  TextFormField(
                    controller: _usernameController,
                    decoration: InputDecoration(
                      labelText: "User ID",
                      prefixIcon: const Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter your User ID';
                      }
                      return null;
                    },
                  ),
                  
                  const SizedBox(height: 20),
                  
                  // Password field
                  TextFormField(
                    controller: _passwordController,
                    decoration: InputDecoration(
                      labelText: "Password",
                      prefixIcon: const Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    obscureText: _obscurePassword,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your password';
                      }
                      return null;
                    },
                  ),
                  
                  const SizedBox(height: 12),
                  
                  // // Forgot password
                  // Align(
                  //   alignment: Alignment.centerRight,
                  //   child: TextButton(
                  //     onPressed: () {
                  //       _usernameController.text = "doc";
                  //       _passwordController.text = "doc";

                  //       setState(() {
                          
                  //       });

                  //     },
                  //     child: const Text("Forgot Password?"),
                  //   ),
                  // ),
                  
                  const SizedBox(height: 20),
                  
                  // Login button
                  SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _login,
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Theme.of(context).primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isLoading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text(
                              "LOGIN",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Sign up option
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Don't have an account?"),
                      TextButton(
                        onPressed: () => Get.to(() => SignupPage()),
                        child: const Text("Sign Up"),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


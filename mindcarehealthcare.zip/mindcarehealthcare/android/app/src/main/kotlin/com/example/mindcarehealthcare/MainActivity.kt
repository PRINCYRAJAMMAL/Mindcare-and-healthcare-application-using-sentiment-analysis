package com.example.mindcarehealthcare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
